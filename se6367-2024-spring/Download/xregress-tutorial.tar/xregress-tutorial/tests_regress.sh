# $Header:@(#) IN /vobs/atac/tutorial/tests_regress /main/3 09/24/98 14:42:06 @(#)$
#!/bin/sh
#
# This file runs test cases and cost assignments used in the xRegress
# tutorial for the wordcount program.
#
# Remove trace file if it already exists.
#
atactm wordcount.trace     > tests_log
rm wordcount.trace tests_log
#
# Run test cases.
#
./wordcount input1            >> tests_log
./wordcount -x input1         >> tests_log
./wordcount < input1          >> tests_log
./wordcount nosuchfile        >> tests_log
./wordcount -wlc input1       >> tests_log
./wordcount input1 input2     >> tests_log
./wordcount "-?"              >> tests_log
./wordcount -l input1         >> tests_log
./wordcount -w input1         >> tests_log
./wordcount -l < input1       >> tests_log
./wordcount -w < input1       >> tests_log
./wordcount -c < input1       >> tests_log
./wordcount -l nosuchfile     >> tests_log
./wordcount -lx input1        >> tests_log
./wordcount input1 nosuchfile >> tests_log
./wordcount empty             >> tests_log
./wordcount input3            >> tests_log
#
# Assign test costs.
#
atactm  -n wordcount.1   -c 120  wordcount.trace
atactm  -n wordcount.2   -c 50   wordcount.trace
atactm  -n wordcount.3   -c 20   wordcount.trace
atactm  -n wordcount.4   -c 10   wordcount.trace
atactm  -n wordcount.5   -c 40   wordcount.trace
atactm  -n wordcount.6   -c 60   wordcount.trace
atactm  -n wordcount.7   -c 80   wordcount.trace
atactm  -n wordcount.8   -c 20   wordcount.trace
atactm  -n wordcount.9   -c 10   wordcount.trace
atactm  -n wordcount.10  -c 70   wordcount.trace
atactm  -n wordcount.11  -c 50   wordcount.trace
atactm  -n wordcount.12  -c 50   wordcount.trace
atactm  -n wordcount.13  -c 50   wordcount.trace
atactm  -n wordcount.14  -c 40   wordcount.trace
atactm  -n wordcount.15  -c 60   wordcount.trace
atactm  -n wordcount.16  -c 20   wordcount.trace
atactm  -n wordcount.17  -c 150  wordcount.trace
